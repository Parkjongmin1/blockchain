const express = require("express");  
const app = express();  
const server = require("http").createServer(app);
const io = require("socket.io")(server);
const bodyParser = require("body-parser");
const multer = require('multer');
const upload = multer({ dest: 'uploads/' }); 
const session = require("express-session");
const bcrypt = require("bcrypt");
const mongoose = require("mongoose");
      

server.listen(8080);
app.use(express.static("public_web"));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.get("/", function(req, res){
    res.sendFile(__dirname + "/public_web/Loginsuccess.html");
});



app.use(session({ secret: 'secret-key', resave: true, saveUninitialized: true }));

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1/login-system', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Define the user schema and model
const userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  phonenumber: String
});
const User = mongoose.model('User', userSchema);

// Define the routes

// Register route
app.post('/sign', async (req, res) => {
  try {
    const { username , email , password, phonenumber  } = req.body;

    // Check if the username is already taken
    const existingUser = await User.findOne({ email });
    if (existingUser) {
	  res.write("<script>alert('User already exist')</script>");
      res.write("<script>window.location=\"index.html\"</script>");
	  return;
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create a new user
    const newUser = new User({
		username,
        email,
        password: hashedPassword,
		phonenumber
    });
    await newUser.save();

    res.write("<script>alert('Sign Complete')</script>");
	res.write("<script>window.location=\"index.html\"</script>");
  } catch (err) {
    console.error('Error registering user:', err);
    res.status(500).send('Internal Server Error');
  }
});

// Login route
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if the user exists
    const user = await User.findOne({ email });
    if (!user) {
	  res.write("<script>alert('email is not existed')</script>");
      res.write("<script>window.location=\"index.html\"</script>");
	  return;
    }

    // Compare the provided password with the stored hashed password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
	  res.write("<script>alert('password wrong')</script>");
      res.write("<script>window.location=\"index.html\"</script>");
	  return;
    }

    req.session.user = user;
	res.write("<script>window.location=\"Loginsuccess.html\"</script>");
  } catch (err) {
    console.error('Error logging in:', err);
    res.status(500).send('Internal Server Error');
  }
});

// Logout route
app.post('/logout', (req, res) => {
  // Destroy the session
  req.session.destroy();
  res.send('Logout successful');
});


const Web3 = require('web3');
const web3 = new Web3('http://127.0.0.1:7545');

const contractABI = [
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "name",
				"type": "string"
			}
		],
		"name": "PetRegistered",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "getPet",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getPetList",
		"outputs": [
			{
				"internalType": "address[]",
				"name": "",
				"type": "address[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "petAddresses",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "pets",
		"outputs": [
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "breed",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "organ",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "image",
				"type": "string"
			},
			{
				"internalType": "uint8",
				"name": "age",
				"type": "uint8"
			},
			{
				"internalType": "bool",
				"name": "isVaccinated",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_breed",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_organ",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_image",
				"type": "string"
			},
			{
				"internalType": "uint8",
				"name": "_age",
				"type": "uint8"
			},
			{
				"internalType": "bool",
				"name": "_isVaccinated",
				"type": "bool"
			}
		],
		"name": "registerPet",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	}
];

// 스마트 계약 주소
const contractAddress = '0xd9145CCE52D386f254917e481eB44e9943F39138'; // 배포된 스마트 계약의 주소를 입력하세요
const contract = new web3.eth.Contract(contractABI, contractAddress);
// 스마트 계약 인스턴스 생성
  

io.on("connection", function(socket) {
	socket.on("registerPet", function(petData) {
	  fetch("http://localhost:8080/register", {
		method: "POST",
		headers: {
			"Content-Type": "application/json" 
		},
		body: JSON.stringify(petData)
	})
	  .then(function(response) {
		if (response.ok) {
			console.log("통신 완료");
		} else {
			console.error("통신 실패");
		}
	  })
	  .catch(function(error) {
		console.error(error);
	});
  });
});
  
  app.post('/register', upload.single('image'), async (req, res) => {
	  const petData = req.body;
  
	
	  
	  const accounts = await web3.eth.getAccounts();
	  const owner = accounts[0];
	  await contract.methods.registerPet(

		  petData.name,
		  petData.breed,
		  petData.organ,
		  petData.image,
		  petData.age,
		  petData.isVaccinated).send({ from: owner, gas: 999999 });
		  
	 const block = await web3.eth.getBlock("latest");
	 const petInfo = {
			  name: petData.name,
			  breed: petData.breed,
			  organ: petData.organ,
			  age: petData.age,
			  isVaccinated: petData.isVaccinated,
			  image: petData.image,
			  blockNumber: block.number,
			  blockTimestamp: block.timestamp,
			  blockHash: block.hash
		  };
	io.emit("petRegistered", petInfo);

	res.end;
	});